import React from 'react';
import './On.scss';

export default function On() {
  return (
    <span className="toggle enabled">
      <span />
    </span>
  );
}
